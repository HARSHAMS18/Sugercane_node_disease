sudo apt-get install pyqt5-dev-tools

sudo pip3 install labelimg

sudo rm -rf /usr/local/lib/python3.11/dist-packages/libs/canvas.py

sudo mv canvas.py /usr/local/lib/python3.11/dist-packages/libs

sudo rm -rf /usr/local/lib/python3.11/dist-packages/labelImg/labelImg.py

sudo mv labelImg.py /usr/local/lib/python3.11/dist-packages/labelImg

