import cv2
import time
import os
from picamera2 import Picamera2

# Directory to save images
save_dir = "/home/rsa/tflite-mediapipe-main/images/"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)
    print(f"Created directory: {save_dir}")
else:
    print(f"Saving images to existing directory: {save_dir}")

# Initialize Picamera2
picam2 = Picamera2()
camera_config = picam2.create_still_configuration(main={"size": (1280, 720)})
picam2.configure(camera_config)
picam2.start()

cpt = 0
maxFrames = 50  # Number of frames to capture

time.sleep(2)  # Allow the camera to warm up

while cpt < maxFrames:
    frame = picam2.capture_array()  # Capture a frame
    cv2.imshow("Test Window", frame)  # Show the image in a window

    # Save the frame to the directory
    file_path = os.path.join(save_dir, f"no_helmet_{cpt}.jpg")
    if not cv2.imwrite(file_path, frame):
        print(f"Failed to save image {cpt} at {file_path}")
    else:
        print(f"Image {cpt} saved successfully at {file_path}")

    time.sleep(0.5)  # Pause for 0.5 seconds between captures
    cpt += 1

    # Stop capturing if ESC key is pressed
    if cv2.waitKey(1) & 0xFF == 27:  # Break on ESC key
        print("Exiting capture loop.")
        break

cv2.destroyAllWindows()
picam2.stop()

print(f"Captured {cpt} images and saved them in {save_dir}")
